"""
voip/migrations/0002_connection_twilio_call_sid.py
===================================================
Adds the twilio_call_sid field to the existing Connection table.

Run with:
    python manage.py migrate voip

What happens to existing rows:
    All existing Connection rows get twilio_call_sid = '' (empty string).
    This is harmless — Zadarma connections never write to this field.
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("voip", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="connection",
            name="twilio_call_sid",
            field=models.CharField(
                blank=True,
                default="",
                help_text="Populated by TwilioWebHook on call completion. Use it to find the recording in the Twilio Console.",
                max_length=34,
                verbose_name="Twilio Call SID",
            ),
        ),
    ]
