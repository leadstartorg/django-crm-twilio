"""
voip/settings.py
=================
Replaces the original voip/settings.py entirely.

WHAT CHANGED
------------
- Zadarma credentials now read from environment variables (were hardcoded).
- Twilio backend added with full pool support (v2 twiliobackend.py).
- All credentials via os.environ — nothing hardcoded.

REQUIRED ENVIRONMENT VARIABLES
--------------------------------
Zadarma (if using Zadarma):
  SECRET_ZADARMA_KEY      Zadarma API key
  SECRET_ZADARMA          Zadarma API secret

Twilio (required):
  TWILIO_ACCOUNT_SID      Starts with "AC" — from console.twilio.com
  TWILIO_AUTH_TOKEN       32-char hex — from console.twilio.com
  TWILIO_TWIML_URL        https://yourcrm.com/voip/twilio/twiml/
  TWILIO_STATUS_URL       https://yourcrm.com/voip/twilio/status/
  TWILIO_WEBHOOK_SECRET   Same value as TWILIO_AUTH_TOKEN

Twilio numbers (one of these is required):
  TWILIO_NUMBER           Single number fallback, e.g. +14045550100
  TWILIO_NUMBER_POOL      Comma-separated list, e.g. +14041112222,+17701113333
                          (pool takes priority over single number when set)
"""

import os

# ---------------------------------------------------------------------------
# Zadarma credentials
# ---------------------------------------------------------------------------
SECRET_ZADARMA_KEY = os.environ.get("SECRET_ZADARMA_KEY", "")
SECRET_ZADARMA = os.environ.get("SECRET_ZADARMA", "")

# ---------------------------------------------------------------------------
# Twilio credentials
# ---------------------------------------------------------------------------
TWILIO_ACCOUNT_SID    = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN     = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_NUMBER         = os.environ.get("TWILIO_NUMBER", "")
TWILIO_NUMBER_POOL    = os.environ.get("TWILIO_NUMBER_POOL", "").split(",")
TWILIO_TWIML_URL      = os.environ.get("TWILIO_TWIML_URL", "")
TWILIO_STATUS_URL     = os.environ.get("TWILIO_STATUS_URL", "")
TWILIO_WEBHOOK_SECRET = os.environ.get("TWILIO_WEBHOOK_SECRET", "")

# ---------------------------------------------------------------------------
# VOIP backend list
# Both providers can coexist. The Connection.provider field (set per agent
# in Django Admin) determines which backend is used for each call.
# ---------------------------------------------------------------------------
VOIP = [
    # ---- Zadarma -----------------------------------------------------------
    {
        "BACKEND":  "voip.backends.zadarmabackend.ZadarmaAPI",
        "PROVIDER": "Zadarma",
        "IP":       "185.45.152.42",   # Zadarma webhook source IP
        "OPTIONS": {
            "key":    SECRET_ZADARMA_KEY,
            "secret": SECRET_ZADARMA,
        },
    },

    # ---- Twilio (with number pool) -----------------------------------------
    {
        "BACKEND":  "voip.backends.twiliobackend.TwilioAPI",
        "PROVIDER": "Twilio",
        "IP":       "",   # Twilio uses signature auth, not IP allowlist
        "OPTIONS": {
            # key / secret → Account SID / Auth Token
            "key":            TWILIO_ACCOUNT_SID,
            "secret":         TWILIO_AUTH_TOKEN,

            # Number selection (v2 pool rotation)
            "twilio_number":  TWILIO_NUMBER,        # single-number fallback
            "number_pool":    TWILIO_NUMBER_POOL,   # list; takes priority when non-empty

            # Webhook URLs
            "twiml_url":      TWILIO_TWIML_URL,
            "status_url":     TWILIO_STATUS_URL,

            # Signature validation (set to same value as AUTH_TOKEN)
            "webhook_secret": TWILIO_WEBHOOK_SECRET,
        },
    },
]

# ---------------------------------------------------------------------------
# Forwarding (original — unchanged)
# Used when a Zadarma webhook arrives for a phone not in this CRM instance,
# and VOIP_FORWARD_DATA is True — re-posts to a second CRM instance.
# ---------------------------------------------------------------------------
VOIP_FORWARD_DATA   = False
VOIP_FORWARDING_IP  = ""
VOIP_FORWARD_URL    = ""
