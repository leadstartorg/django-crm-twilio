"""
voip/views/twiml.py
====================
NEW FILE — no equivalent exists in the original django-crm.

What it does
------------
Twilio calls this URL (via HTTP GET) when the agent answers the
outbound callback. We return a TwiML <Dial> instruction that tells
Twilio to bridge the agent's live call to the lead's number.

URL:  /voip/twilio/twiml/?to=+14045551234
      The ?to= parameter is appended by TwilioAPI.make_query() when it
      creates the Twilio call. It carries the lead's phone number.

Flow
----
  1. Agent clicks phone icon in CRM admin.
  2. TwilioAPI.make_query() POSTs to Twilio REST API.
  3. Twilio dials the AGENT's number (connection.number).
  4. Agent answers their phone.
  5. Twilio fetches GET /voip/twilio/twiml/?to=+14045551234
  6. This view returns: <Response><Dial><Number>+14045551234</Number></Dial></Response>
  7. Twilio dials the lead and bridges the two calls.

Security
--------
Twilio signs every request with X-Twilio-Signature.
We validate it here using TWILIO_WEBHOOK_SECRET (= your Auth Token).
In development without HTTPS, set TWILIO_WEBHOOK_SECRET="" to skip validation.
"""

import logging
from django.conf import settings
from django.http import HttpResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

logger = logging.getLogger(__name__)


def _get_twilio_options() -> dict:
    """Return OPTIONS dict for the Twilio backend from settings.VOIP."""
    for backend in settings.VOIP:
        if backend.get("PROVIDER") == "Twilio":
            return backend.get("OPTIONS", {})
    return {}


def _validate_twilio_signature(request) -> bool:
    """
    Validate X-Twilio-Signature header.
    Returns True if valid, or if webhook_secret is not set (dev mode).
    """
    options = _get_twilio_options()
    auth_token = options.get("webhook_secret") or options.get("secret", "")

    if not auth_token:
        logger.warning(
            "TwilioTwiML: TWILIO_WEBHOOK_SECRET not set — skipping signature "
            "validation. Set it in production."
        )
        return True

    try:
        from twilio.request_validator import RequestValidator
        validator = RequestValidator(auth_token)
        url = request.build_absolute_uri()
        signature = request.META.get("HTTP_X_TWILIO_SIGNATURE", "")
        params = request.POST.dict() if request.method == "POST" else {}
        return validator.validate(url, params, signature)
    except ImportError:
        logger.warning(
            "twilio package not installed — cannot validate signature. "
            "Run: pip install twilio"
        )
        return True


@method_decorator(csrf_exempt, name="dispatch")
class TwilioTwiML(View):
    """Returns TwiML that dials the lead once the agent answers."""

    def get(self, request, *args, **kwargs):
        if not _validate_twilio_signature(request):
            logger.warning("TwilioTwiML: invalid Twilio signature — rejected.")
            return HttpResponse("Forbidden", status=403)

        to_number = request.GET.get("to", "").strip()

        if not to_number:
            logger.error("TwilioTwiML: called without ?to= parameter.")
            twiml = (
                '<?xml version="1.0" encoding="UTF-8"?>'
                "<Response>"
                "<Say>Configuration error. The destination number is missing.</Say>"
                "</Response>"
            )
            return HttpResponse(twiml, content_type="application/xml", status=400)

        # Use the pool-selected caller ID that was chosen in make_query()
        # For the <Dial> callerId we use the Twilio number from settings as fallback
        options = _get_twilio_options()
        caller_id = options.get("twilio_number", to_number)
        # If a pool is configured, use the first pool number as the caller ID fallback
        pool = [n.strip() for n in options.get("number_pool", []) if n and n.strip()]
        if pool and not caller_id:
            caller_id = pool[0]

        twiml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            "<Response>"
            f'<Dial callerId="{caller_id}">'
            f"<Number>{to_number}</Number>"
            "</Dial>"
            "</Response>"
        )

        logger.info("TwilioTwiML: bridging call to %s", to_number)
        return HttpResponse(twiml, content_type="application/xml")
