"""
voip/views/twiliowebhook.py
============================
NEW FILE — mirrors VoIPWebHook from voipwebhook.py (Zadarma) in structure.

What it does
------------
Receives POST status events from Twilio after calls change state.
Only "completed" events update the CRM.

On a completed call it:
  1. Validates the X-Twilio-Signature to confirm the request is from Twilio.
  2. Finds the Contact/Lead and their active Deal by the lead's phone number.
  3. Calls was_in_touch_today() on the Contact/Lead.
  4. Appends a workflow entry to the Deal (e.g. "An outgoing call to Jane Doe
     (duration: 2.3 minutes).").
  5. Stores the Twilio CallSid on the Connection.twilio_call_sid field.
  6. Optionally forwards to VOIP_FORWARD_URL if no CRM record is found
     (mirrors Zadarma forwarding behaviour).

URL: /voip/twilio/status/
Set as StatusCallback when TwilioAPI.make_query() creates the Twilio call.

Twilio POST fields used
-----------------------
  CallSid       Unique call ID (CA...)
  CallStatus    initiated|ringing|in-progress|completed|busy|failed|no-answer
  To            Agent's number (Twilio dialled this first)
  From          Twilio number used as caller ID
  Direction     outbound-api / inbound / etc.
  Duration      Call length in seconds (only on "completed")
  ForwardedTo   Lead's number if set by <Dial><Number> bridge
  Called        Fallback for lead's number
"""

import re
import logging
import requests

from django.conf import settings
from django.http import HttpResponse, HttpRequest
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from typing import Optional, Tuple

from common.utils.helpers import add_phone_q_params
from crm.models import Contact, Deal, Lead

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_twilio_options() -> dict:
    """Return OPTIONS for the Twilio provider from settings.VOIP."""
    for backend in settings.VOIP:
        if backend.get("PROVIDER") == "Twilio":
            return backend.get("OPTIONS", {})
    return {}


def is_authenticated(request: HttpRequest, _data: str = "") -> bool:
    """
    Validate X-Twilio-Signature.
    _data is kept for interface parity with voipwebhook.py but not used here —
    Twilio authenticates via HMAC over the full URL + sorted POST params,
    not a custom data string like Zadarma.
    """
    options = _get_twilio_options()
    auth_token = options.get("webhook_secret") or options.get("secret", "")

    if not auth_token:
        logger.warning(
            "TwilioWebHook: TWILIO_WEBHOOK_SECRET not set — skipping signature "
            "validation. Set it in production."
        )
        return True

    try:
        from twilio.request_validator import RequestValidator
        validator = RequestValidator(auth_token)
        url = request.build_absolute_uri()
        signature = request.META.get("HTTP_X_TWILIO_SIGNATURE", "")
        return validator.validate(url, request.POST.dict(), signature)
    except ImportError:
        logger.warning(
            "twilio package not installed — skipping signature validation. "
            "Install with: pip install twilio"
        )
        return True


def find_objects_by_phone(
    phone: str,
) -> Tuple[Optional[Contact], Optional[Lead], Optional[Deal], str]:
    """Search Contact, Lead, and active Deal by phone number."""
    params = contact = lead = deal = None
    q_params = add_phone_q_params(phone)
    try:
        contact = Contact.objects.filter(q_params).first()
    except Exception as exc:
        return contact, lead, deal, str(exc)
    if contact:
        params = {"contact_id": contact.id, "active": True}
    else:
        lead = Lead.objects.filter(q_params).first()
        if lead:
            params = {"lead_id": lead.id, "active": True}
    if any((contact, lead)):
        deal = Deal.objects.filter(**params).order_by("-update_date").first()
    return contact, lead, deal, ""


def _store_call_sid(agent_phone: str, call_sid: str) -> None:
    """Write Twilio CallSid to Connection.twilio_call_sid for the matching agent."""
    try:
        from voip.models import Connection
        conn = Connection.objects.filter(
            number=agent_phone, provider="Twilio", active=True
        ).first()
        if conn:
            conn.twilio_call_sid = call_sid
            conn.save(update_fields=["twilio_call_sid"])
    except Exception as exc:
        logger.warning("TwilioWebHook: could not store call_sid: %s", exc)


# ---------------------------------------------------------------------------
# Webhook view
# ---------------------------------------------------------------------------

@method_decorator(csrf_exempt, name="dispatch")
class TwilioWebHook(View):
    """Receives Twilio call status events and updates the CRM."""

    @staticmethod
    def get(request: HttpRequest) -> HttpResponse:
        # Twilio may send a GET to verify the endpoint during initial setup
        return HttpResponse("OK", status=200)

    @staticmethod
    def post(request: HttpRequest) -> HttpResponse:
        call_status: str = request.POST.get("CallStatus", "")
        call_sid: str    = request.POST.get("CallSid", "")
        direction: str   = request.POST.get("Direction", "")

        logger.debug(
            "TwilioWebHook: CallSid=%s  Status=%s  Direction=%s",
            call_sid, call_status, direction,
        )

        # Acknowledge non-terminal statuses and return early
        # (mirrors NOTIFY_RECORD discard in VoIPWebHook)
        if call_status not in ("completed", "busy", "failed", "no-answer", "canceled"):
            return HttpResponse("", status=200)

        # Validate Twilio signature before any DB work
        if not is_authenticated(request):
            logger.warning(
                "TwilioWebHook: invalid signature for CallSid=%s — rejected.", call_sid
            )
            return HttpResponse("Forbidden", status=403)

        # Only write CRM entries for fully answered and completed calls
        if call_status != "completed":
            return HttpResponse("", status=200)

        # ----------------------------------------------------------------
        # Determine the lead's phone number.
        # For outbound callbacks: Twilio dialled the AGENT first (To = agent).
        # ForwardedTo is set by Twilio's <Dial><Number> bridge to the lead.
        # ----------------------------------------------------------------
        agent_phone: str   = request.POST.get("To", "")
        forwarded_to: str  = request.POST.get("ForwardedTo", "")
        lead_phone: str    = forwarded_to or request.POST.get("Called", "")
        phone              = lead_phone or agent_phone

        # Strip formatting — keep only digits and leading +
        phone = re.sub(r"[^\d+]", "", phone)

        duration_seconds: int = 0
        try:
            duration_seconds = int(request.POST.get("Duration", 0))
        except (ValueError, TypeError):
            pass
        duration_min = round(duration_seconds / 60, 1)

        contact, lead, deal, err = find_objects_by_phone(phone)

        if err:
            logger.error(
                "TwilioWebHook: DB error looking up phone %s: %s", phone, err
            )
            return HttpResponse("", status=200)

        obj = contact or lead
        full_name = ""
        if obj:
            obj.was_in_touch_today()
            full_name = obj.full_name

        if deal:
            direction_label = (
                _("An outgoing call to") if "outbound" in direction
                else _("An incoming call from")
            )
            duration_str = _(f"(duration: {duration_min} minutes)")
            entry = f"{direction_label} {full_name} {duration_str}."
            deal.add_to_workflow(entry)
            deal.save()

        # Store CallSid on Connection for audit trail
        if call_sid and agent_phone:
            _store_call_sid(agent_phone, call_sid)

        # Forward if no local record found (mirrors Zadarma forwarding logic)
        if not any((contact, lead, deal)) and settings.VOIP_FORWARD_DATA:
            url = settings.VOIP_FORWARD_URL
            try:
                requests.post(url, data=request.POST, timeout=5)
            except requests.RequestException as exc:
                logger.warning("TwilioWebHook: forward to %s failed: %s", url, exc)

        return HttpResponse("", status=200)
