"""
voip/models.py
===============
Original Connection model plus one new field: twilio_call_sid.

WHAT CHANGED FROM THE ORIGINAL
--------------------------------
Added twilio_call_sid CharField at the bottom of the class.

- Zadarma connections: this field stays blank (empty string). No impact.
- Twilio connections: TwilioWebHook writes the Twilio CallSid here after
  each completed call so you can look up the recording in Twilio Console.

NOTE ON FIELD NAME
------------------
The user asked about adding a field named "call_sid". We use "twilio_call_sid"
instead for two reasons:
  1. Prefixing with "twilio_" makes the field self-documenting — you know at
     a glance it is Twilio-specific and not a generic CRM field.
  2. If a second VoIP provider is added later (e.g. Vonage), you can add
     vonage_call_id alongside it without confusion.

The migration (0002_connection_twilio_call_sid.py) uses the same name.
"""

from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _


class Connection(models.Model):

    TYPE_CHOICES = [
        ('pbx',  _('PBX extension')),
        ('sip',  _('SIP connection')),
        ('voip', _('Virtual phone number')),
    ]

    # Dynamically built from settings.VOIP so new providers appear automatically
    PROVIDER_CHOICES = (
        (backend['PROVIDER'], backend['PROVIDER'])
        for backend in settings.VOIP
    )

    type = models.CharField(
        max_length=4,
        default='pbx',
        blank=False,
        choices=TYPE_CHOICES,
        verbose_name=_("Type"),
    )
    active = models.BooleanField(
        default=False,
        verbose_name=_("Active"),
    )
    number = models.CharField(
        max_length=30,
        null=False,
        blank=False,
        verbose_name=_("Number"),
    )
    callerid = models.CharField(
        max_length=30,
        null=False,
        blank=False,
        verbose_name=_("Caller ID"),
        help_text=_(
            'Specify the number to be displayed as '
            'your phone number when you call'
        ),
    )
    provider = models.CharField(
        max_length=100,
        null=False,
        blank=False,
        choices=PROVIDER_CHOICES,
        verbose_name=_("Provider"),
        help_text=_('Specify VoIP service provider'),
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        verbose_name=_("Owner"),
        related_name="%(app_label)s_%(class)s_owner_related",
    )

    # -----------------------------------------------------------------------
    # NEW — Twilio only
    # Populated by TwilioWebHook._store_call_sid() on call completion.
    # Zadarma rows: this stays as empty string "". No migration data needed.
    # -----------------------------------------------------------------------
    twilio_call_sid = models.CharField(
        max_length=34,
        blank=True,
        default='',
        verbose_name=_("Twilio Call SID"),
        help_text=_(
            "Populated by TwilioWebHook on call completion. "
            "Use it to find the recording in the Twilio Console."
        ),
    )
