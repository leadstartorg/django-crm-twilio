"""
voip/urls.py
=============
Replaces the original voip/urls.py.

WHAT CHANGED
------------
Two Twilio routes added at the bottom.
Original Zadarma routes are completely unchanged.

URL map
-------
  /voip/get-callback/       ConnectionView       Agent clicks phone icon
  /voip/zd/                 VoIPWebHook          Zadarma → CRM status webhook
  /voip/twilio/twiml/       TwilioTwiML          Twilio fetches this when agent answers
  /voip/twilio/status/      TwilioWebHook        Twilio → CRM status webhook
"""

from django.urls import path

# Original views — unchanged
from voip.views.callback import ConnectionView
from voip.views.voipwebhook import VoIPWebHook

# New Twilio views
from voip.views.twiml import TwilioTwiML
from voip.views.twiliowebhook import TwilioWebHook

urlpatterns = [
    # -----------------------------------------------------------------------
    # Original Zadarma routes — DO NOT modify
    # -----------------------------------------------------------------------
    path(
        'get-callback/',
        ConnectionView.as_view(),
        name='get_callback',
    ),
    path(
        'zd/',
        VoIPWebHook.as_view(),
        name='voip-zadarma-pbx-notification',
    ),

    # -----------------------------------------------------------------------
    # Twilio routes — NEW
    # -----------------------------------------------------------------------
    # Twilio fetches this URL when the agent answers the callback call.
    # Returns TwiML <Dial> that bridges the agent to the lead's number.
    path(
        'twilio/twiml/',
        TwilioTwiML.as_view(),
        name='twilio-twiml',
    ),
    # Twilio posts call status events here (initiated, ringing, completed…).
    path(
        'twilio/status/',
        TwilioWebHook.as_view(),
        name='twilio-status-webhook',
    ),
]
