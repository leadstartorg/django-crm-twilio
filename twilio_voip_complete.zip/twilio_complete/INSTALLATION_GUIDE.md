# Twilio VoIP + Google Voice — Beginner Installation Guide
## django-crm · Step-by-Step · No Experience Assumed

---

## Before You Start — What You Need

1. A running django-crm installation (it already works without VoIP).
2. A Twilio account — sign up free at **console.twilio.com**. You get a trial number at no cost.
3. SSH or terminal access to your server, OR your local development machine.
4. About 20 minutes.

---

## How This Works (Plain English)

When an agent clicks a phone number in the CRM, here is what happens:

```
Agent clicks phone number in CRM
         ↓
CRM tells Twilio: "Call agent first, then lead"
         ↓
Twilio calls the agent's cell phone
         ↓
Agent picks up their phone
         ↓
Twilio fetches a small instruction from your server (TwiML)
         ↓
Twilio dials the lead and connects the two calls
         ↓
Call ends → Twilio notifies your server → CRM logs the call
```

---

## SECTION 1 — Questions Answered First

### Q: Do I replace twiliobackend.py or add it alongside?

**Replace it.** The file you uploaded (`twiliobackend_v2.py`) is the final version. Copy it into `voip/backends/` as `twiliobackend.py`. There is no v1 to keep — v2 is strictly better (adds pool rotation, keeps the same interface).

### Q: Do I edit models.py or just add a field?

You **replace** `voip/models.py` with the one provided. The file contains the original model plus one new field (`twilio_call_sid`). Then you run `python manage.py migrate voip` to add the column to your database. Django reads the migration file (`0002_connection_twilio_call_sid.py`) and adds the column automatically.

### Q: What is `twilio_call_sid` vs `call_sid`?

You asked about adding a field named `call_sid`. We named it `twilio_call_sid` instead. Both work. The longer name is clearer — in two years when you look at the database you will know immediately that this column belongs to Twilio, not some other system. The migration and model file in this package use `twilio_call_sid`.

### Q: Do I update .env or create it?

**Update it if it exists. Create it if it doesn't.**
Check your project root for a file named `.env`. If it exists, add the Twilio lines to it. If it doesn't, create it and copy in the contents of `sample.env` (provided in this package).

### Q: TWILIO_WEBHOOK_SECRET is the same as TWILIO_AUTH_TOKEN — is that right?

**Yes, exactly.** Twilio uses your Auth Token to sign webhook requests. There is no separate "webhook secret" for Twilio the way Stripe has one. You set both variables to the same value so that if you ever rotate one, you rotate both. The code reads them as separate variables for clarity.

### Q: Do I need the pool? Can I just use one number?

You can use just one number. Set `TWILIO_NUMBER` and leave `TWILIO_NUMBER_POOL` empty. The pool is optional — it increases answer rates by showing leads a "local" area code instead of a generic number, but it is not required.

---

## SECTION 2 — File Map (What Goes Where)

```
Your django-crm project/
│
├── voip/                           ← the VoIP app folder
│   ├── __init__.py                 (no change — already exists)
│   ├── admin.py                    (no change)
│   ├── apps.py                     (no change)
│   │
│   ├── settings.py                 ← REPLACE with file from this package
│   ├── models.py                   ← REPLACE with file from this package
│   ├── urls.py                     ← REPLACE with file from this package
│   │
│   ├── backends/
│   │   ├── __init__.py             (no change)
│   │   ├── zadarmabackend.py       (no change)
│   │   └── twiliobackend.py        ← NEW — copy from this package
│   │
│   ├── forms/
│   │   └── connectionform.py       (no change)
│   │
│   ├── migrations/
│   │   ├── __init__.py             (no change)
│   │   ├── 0001_initial.py         (no change)
│   │   └── 0002_connection_twilio_call_sid.py  ← NEW — copy from this package
│   │
│   ├── views/
│   │   ├── __init__.py             (no change)
│   │   ├── callback.py             (no change)
│   │   ├── voipwebhook.py          (no change)
│   │   ├── twiml.py                ← NEW — copy from this package
│   │   └── twiliowebhook.py        ← NEW — copy from this package
│   │
│   └── templates/voip/
│       └── connection.html         (no change)
│
├── crm/site/
│   └── crmmodeladmin.py            ← EDIT (3 small changes — see patch file)
│
└── sample.env                      ← READ THIS, then add values to your .env
```

---

## SECTION 3 — Step-by-Step Installation

### Step 1 — Install the Twilio Python package

Open your terminal and run:

```bash
pip install twilio
```

Then add it to your requirements file so it installs on future deployments:

```bash
echo "twilio>=9.0" >> requirements.txt
```

---

### Step 2 — Copy the new and replacement files

Copy each file from this package to your project. The table below shows exactly where each file goes.

| File in this package | Copy to this path in your project |
|---------------------|----------------------------------|
| `voip/backends/twiliobackend.py` | `voip/backends/twiliobackend.py` |
| `voip/settings.py` | `voip/settings.py` (replaces original) |
| `voip/models.py` | `voip/models.py` (replaces original) |
| `voip/urls.py` | `voip/urls.py` (replaces original) |
| `voip/views/twiml.py` | `voip/views/twiml.py` (new file) |
| `voip/views/twiliowebhook.py` | `voip/views/twiliowebhook.py` (new file) |
| `voip/migrations/0002_connection_twilio_call_sid.py` | `voip/migrations/0002_connection_twilio_call_sid.py` (new file) |

**If you use git**, after copying run `git status` to confirm the right files were changed:
```bash
git status
# You should see: modified voip/settings.py, voip/models.py, voip/urls.py
#                 new file: voip/backends/twiliobackend.py
#                 new file: voip/views/twiml.py
#                 new file: voip/views/twiliowebhook.py
#                 new file: voip/migrations/0002_connection_twilio_call_sid.py
```

---

### Step 3 — Set your environment variables

**Find your Twilio credentials:**
1. Go to https://console.twilio.com/
2. Your **Account SID** and **Auth Token** are on the dashboard home page.
3. Your phone number is under Phone Numbers → Manage → Active numbers.

**Open (or create) your `.env` file** in your project root:

```bash
# If .env exists, open it in your editor and ADD these lines:
# If .env doesn't exist, create it and copy in sample.env contents.

TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx    # your Account SID
TWILIO_AUTH_TOKEN=your_32_char_auth_token_here           # your Auth Token
TWILIO_WEBHOOK_SECRET=your_32_char_auth_token_here       # same as AUTH_TOKEN

# Single number (simplest):
TWILIO_NUMBER=+14045550100

# Number pool (optional, for better answer rates):
# TWILIO_NUMBER_POOL=+14041112222,+17701113333,+16781114444

# Your CRM's public URLs (must be HTTPS in production):
TWILIO_TWIML_URL=https://yourcrm.com/voip/twilio/twiml/
TWILIO_STATUS_URL=https://yourcrm.com/voip/twilio/status/
```

**Important:** Replace `ACxxxxxxxx...` and the auth token with your actual values from the Twilio console. Replace `yourcrm.com` with your actual domain.

**For local development** (no public URL yet), see Section 5 — ngrok setup.

---

### Step 4 — Run the database migration

This adds the `twilio_call_sid` column to the `Connection` table:

```bash
python manage.py migrate voip
```

Expected output:
```
Operations to perform:
  Apply all migrations: voip
Running migrations:
  Applying voip.0002_connection_twilio_call_sid... OK
```

If you see `OK` you are done with this step. If you see an error, check that:
- You copied `0002_connection_twilio_call_sid.py` to the right migrations folder.
- `0001_initial.py` exists in the same folder (it should already be there).

---

### Step 5 — Add Google Voice links (optional, 3 edits)

Open `crm/site/crmmodeladmin.py` in your editor. Make the three changes shown in `crm/site/crmmodeladmin_google_voice_patch.py`.

**Change 1** — Add two constants after line 72:
```python
# Find this line:
whatsapp_chat_tip = _("Chat or WhatsApp call")

# Add these two lines immediately after it:
google_voice_chat = _("Google Voice call")
google_voice_tip = _("Call via Google Voice in browser")
```

**Change 2** — In the `messengers()` method, add one `<li>` before `</ul>`:
```python
# Add this line before the closing </ul>:
<li><a title="{google_voice_tip}" href="https://voice.google.com/u/0/calls?a=nc,{number}" target="_blank">{google_voice_chat}</a></li>\
```

**Change 3** — In the `connections()` method, add one `<li>` before the closing `</ul>`:
```python
# Add this block after the WhatsApp </li>:
<li>
    <a title="{google_voice_tip}" href="https://voice.google.com/u/0/calls?a=nc,{number}" target="_blank">
        {google_voice_chat}
    </a>
</li>
```

See the `crmmodeladmin_google_voice_patch.py` file in this package for the exact surrounding context to help you find the right spots.

---

### Step 6 — Restart Django

```bash
# If using gunicorn:
sudo systemctl restart gunicorn

# If running locally:
python manage.py runserver
```

---

### Step 7 — Create a Twilio Connection in Django Admin

1. Open your CRM and go to **Admin → VoIP → Connections → Add Connection**.
2. Fill in these fields:

| Field | What to enter |
|-------|---------------|
| Provider | `Twilio` (this option now appears in the dropdown) |
| Active | Check the box ✓ |
| Number | The agent's personal phone in E.164 format: `+14045550199` |
| Caller ID | Same as Number (or a label) |
| Type | `pbx` |
| Owner | Select the agent's Django user account |

3. Click **Save**.

Repeat for each agent who will use Twilio.

---

### Step 8 — Test the call

1. Open a Lead or Contact in the CRM admin.
2. Click the phone number in the phone column.
3. A small popup appears saying "Expect a call to your smartphone."
4. Your phone rings. Answer it.
5. After a couple of seconds, you will hear a second dial tone, then the lead's phone rings.
6. After the call, check the Deal's workflow log — you should see an entry like: `"An outgoing call to Jane Doe (duration: 1.2 minutes)."`

---

## SECTION 4 — Verifying the Pool Works

If you set up `TWILIO_NUMBER_POOL`, check your Django logs after a call:

```
INFO TwilioAPI: call initiated — SID CA... | from=+14045550199 to=+14045551234 via pool=+14041112222
```

The `via pool=` part shows which number was selected. If the area code matched, the log also shows:
```
DEBUG TwilioAPI: area-code 404 matched → selected +14041112222 from pool ['+14041112222']
```

---

## SECTION 5 — Local Development with ngrok

Twilio can't reach `localhost`. Use ngrok to create a temporary public URL.

**Install ngrok:** https://ngrok.com/download

```bash
# Terminal 1 — run Django
python manage.py runserver 8000

# Terminal 2 — expose port 8000 publicly
ngrok http 8000
```

ngrok prints something like:
```
Forwarding   https://abc123.ngrok-free.app → localhost:8000
```

Set your `.env` to use the ngrok URL:
```
TWILIO_TWIML_URL=https://abc123.ngrok-free.app/voip/twilio/twiml/
TWILIO_STATUS_URL=https://abc123.ngrok-free.app/voip/twilio/status/
```

Restart Django after changing `.env`. Note: the ngrok URL changes every time you restart ngrok (unless you have a paid account with a reserved domain).

---

## SECTION 6 — Troubleshooting

| What you see | What it means | Fix |
|-------------|---------------|-----|
| "You do not have a VoIP connection configured" | No active Connection for this user | Go to Admin → VoIP → Connections and add one for this user |
| "Error! 21212" | Agent's number format is wrong | Edit the Connection — number must be E.164: `+14045550199` |
| "Error! 21606" | `TWILIO_NUMBER` not set or not a real Twilio number | Check `.env`, verify the number in Twilio Console |
| "Error! Twilio provider not found" | `voip/settings.py` not updated | Confirm you replaced `voip/settings.py` with the one from this package |
| Popup says "Expect a call" but phone never rings | Wrong agent number in Connection | Edit the Connection — `number` must be the agent's actual mobile/desk number |
| Call connects agent but never dials lead | TwiML URL wrong or unreachable | Check `TWILIO_TWIML_URL`, confirm Django is running, test with `curl https://yourcrm.com/voip/twilio/twiml/?to=+14045551234` |
| 403 Forbidden on webhook | Signature mismatch | Check `TWILIO_WEBHOOK_SECRET` equals your Auth Token exactly |
| "No caller ID available" error | `TWILIO_NUMBER` and `TWILIO_NUMBER_POOL` both empty | Set at least one in `.env` |
| `ImportError: No module named 'twilio'` | Package not installed | Run `pip install twilio` |
| Migration says "already exists" | You ran migrate twice | Safe to ignore — Django skips already-applied migrations |

---

## SECTION 7 — What Each File Does (Reference)

| File | Role |
|------|------|
| `voip/backends/twiliobackend.py` | Talks to the Twilio REST API. Picks the best caller ID from your pool. Returns `{"status":"success"}` or `{"status":"error"}`. |
| `voip/settings.py` | Lists your VoIP providers and reads credentials from environment variables. |
| `voip/models.py` | The `Connection` database model. One row per agent. Added `twilio_call_sid` field. |
| `voip/urls.py` | URL routing. Maps `/voip/twilio/twiml/` and `/voip/twilio/status/` to the new views. |
| `voip/views/twiml.py` | Called by Twilio when the agent answers. Returns XML that tells Twilio to dial the lead. |
| `voip/views/twiliowebhook.py` | Called by Twilio when the call ends. Updates the CRM — logs the call in the Deal's workflow. |
| `voip/migrations/0002_...py` | Adds the `twilio_call_sid` column to the database. Run once with `migrate`. |
| `crmmodeladmin_google_voice_patch.py` | Instructions for adding Google Voice links to the phone column. |
| `sample.env` | Template showing all environment variables to set. |
