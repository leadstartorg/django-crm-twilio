"""
crm/site/crmmodeladmin_google_voice_patch.py
=============================================
This is NOT a replacement file. It shows the exact three changes to make
to crm/site/crmmodeladmin.py to add Google Voice links.

Apply these changes by hand — do not replace the whole file.
"""

# ===========================================================================
# CHANGE 1 of 3
# Location: Lines 71-72 (after whatsapp_chat_tip)
# Action: ADD two lines immediately after whatsapp_chat_tip
# ===========================================================================

# EXISTING lines 71-72 (leave these as-is, just add below them):
# whatsapp_chat = _("WhatsApp chat")
# whatsapp_chat_tip = _("Chat or WhatsApp call")

# ADD these two lines right after:
# google_voice_chat = _("Google Voice call")
# google_voice_tip = _("Call via Google Voice in browser")


# ===========================================================================
# CHANGE 2 of 3
# Location: The messengers() method return statement (~lines 408-414)
# Action: Add one <li> for Google Voice
# ===========================================================================

# FIND this exact block (the return statement inside messengers()):
ORIGINAL_MESSENGERS = """
        return mark_safe(
            f'<ul class=\"object-tools\" style=\"margin-left: 0px;margin-top: 0px;\">\\
                <li><a title=\"{viber_chat_tip}\" href=\"viber://chat/?number={number}\">{viber_chat}</a></li>\\
                <li><a title=\"{whatsapp_chat_tip}\" href=\"https://wa.me/{number}/?text=Hi!\" target=\"_blank\">\\
                {whatsapp_chat}</a></li>\\
            </ul>'
        )
"""

# REPLACE WITH (adds Google Voice as third <li>):
UPDATED_MESSENGERS = """
        return mark_safe(
            f'<ul class=\"object-tools\" style=\"margin-left: 0px;margin-top: 0px;\">\\
                <li><a title=\"{viber_chat_tip}\" href=\"viber://chat/?number={number}\">{viber_chat}</a></li>\\
                <li><a title=\"{whatsapp_chat_tip}\" href=\"https://wa.me/{number}/?text=Hi!\" target=\"_blank\">\\
                {whatsapp_chat}</a></li>\\
                <li><a title=\"{google_voice_tip}\" href=\"https://voice.google.com/u/0/calls?a=nc,{number}\" target=\"_blank\">\\
                {google_voice_chat}</a></li>\\
            </ul>'
        )
"""


# ===========================================================================
# CHANGE 3 of 3
# Location: The connections() method return statement (~lines 548-565)
# Action: Add one <li> for Google Voice after the WhatsApp </li>
# ===========================================================================

# FIND this exact block inside connections():
ORIGINAL_CONNECTIONS = """
        return mark_safe(
            f'''
            {phone}
                <ul class=\"object-tools\" style=\"margin-left: 0px;margin-top: 0px;\">\\
                    <li>
                        <a title=\"{smartphone_callback_tip}\" href=\"#\" onClick=\"{onclick}\">\\
                        {smartphone_callback}</a>
                    </li>\\
                    <li><a title=\"{viber_chat_tip}\" href=\"viber://chat/?number={number}\">{viber_chat}</a></li>\\
                    <li>
                        <a title=\"{whatsapp_chat_tip}\" href=\"https://wa.me/{number}/?text=Hi!\" target=\"_blank\">
                            {whatsapp_chat}
                        </a>\\
                    </li>
                </ul>
            '''
        )
"""

# REPLACE WITH (adds Google Voice <li> before closing </ul>):
UPDATED_CONNECTIONS = """
        return mark_safe(
            f'''
            {phone}
                <ul class=\"object-tools\" style=\"margin-left: 0px;margin-top: 0px;\">\\
                    <li>
                        <a title=\"{smartphone_callback_tip}\" href=\"#\" onClick=\"{onclick}\">\\
                        {smartphone_callback}</a>
                    </li>\\
                    <li><a title=\"{viber_chat_tip}\" href=\"viber://chat/?number={number}\">{viber_chat}</a></li>\\
                    <li>
                        <a title=\"{whatsapp_chat_tip}\" href=\"https://wa.me/{number}/?text=Hi!\" target=\"_blank\">
                            {whatsapp_chat}
                        </a>\\
                    </li>
                    <li>
                        <a title=\"{google_voice_tip}\" href=\"https://voice.google.com/u/0/calls?a=nc,{number}\" target=\"_blank\">
                            {google_voice_chat}
                        </a>
                    </li>
                </ul>
            '''
        )
"""

# ===========================================================================
# NOTES ON THE GOOGLE VOICE URL
# ===========================================================================
#
# URL format: https://voice.google.com/u/0/calls?a=nc,{number}
#
#   /u/0/        First Google account signed in to the browser. Change to
#                /u/1/ if agents use a secondary account.
#   ?a=nc,       action=new_call
#   {number}     E.164 format — uses the same `number` variable already
#                computed in both methods (+14045551234).
#
# Requirements:
#   - Agent must be signed in to Google in the same browser.
#   - Agent must have Google Voice active on that Google account.
#   - Google Voice is free for US consumers. No server-side config needed.
#   - Works on desktop (Chrome, Firefox, Edge). On mobile may open the app.
#
# This is a client-side link only — no server code, no credentials,
# no webhook, no backend class. Exactly like Viber and WhatsApp.
